<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <style>
        img{
            width: 100%; 
            height: 350px; 
            object-fit: cover; 
        }
    </style>
</head>
<body>
                <div id="carouselExampleIndicators" class="carousel slide">
                    <div class="carousel-indicators">
                        <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                        <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
                        <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
                    </div>
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                        <img src="./src/g4.jpg" class="d-block w-100" alt="...">
                        </div>
                        <div class="carousel-item">
                        <img src="./src/g5.jpg" class="d-block w-100" alt="...">
                        </div>
                        <div class="carousel-item">
                        <img src="./src/g6.jpg" class="d-block w-100" alt="...">
                        </div>
                    </div>
                    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Previous</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Next</span>
                    </button>
                </div>

    <div class="container px-4 px-lg-5 d-flex h-100 align-items-center justify-content-center">
        <div class="d-flex justify-content-center">
            <div class="text-center mt-4">
                <h1 class="mx-auto my-0">Selamat Datang di Toko Hadyan</h1>
                <h5 class="text-black-50 mx-auto mt-5 mb-5">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Expedita, a modi! Illum molestiae animi ipsa minima delectus aliquid debitis voluptatibus sequi culpa molestias consectetur, deserunt beatae cupiditate, placeat esse sed cum at voluptatum provident perspiciatis veniam ratione impedit sit voluptate. Quisquam vitae facilis perferendis aut quo, facere molestiae alias, ipsum dolorum voluptates voluptas aspernatur magni quidem obcaecati minus dolor modi ad explicabo temporibus quibusdam tempore laudantium nobis! Magni eius eveniet veniam similique quisquam repellendus tempore qui repellat. Ex dolore nostrum dolores quae illo incidunt, veniam ullam magnam totam pariatur, officiis sint vero, maiores at corporis cupiditate tempora nam beatae expedita.</h5>
                <a class="btn btn-primary" href="index.php?hal=product">Mulai Belanja</a>
            </div>
        </div>
    </div>
</body>
</html>
