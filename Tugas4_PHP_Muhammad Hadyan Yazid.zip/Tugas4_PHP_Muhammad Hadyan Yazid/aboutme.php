<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Me</title>
    <style>
        .profile-img {
            border-radius: 50%;
            width: 100%;
            max-width: 250px;
        }
    </style>
</head>
<body>
<div class='container'>
    <div class='row'>
        <img src="https://github.com/mhyazid/tugas/blob/9dff7508848d383fa0db0bffd6e47317acf27e1e/src/hadyan.jpg?raw=true" alt="Profile Picture" class="profile-img mx-auto mt-4">
        <div class='container mt-5 text-justify border border-dark-subtle p-4 rounded'>
        <p>Nama saya adalah Muhammad Hadyan Yazid. Saya biasa dipanggil dengan nama Hadyan atau Yazid. Saya merupakan seorang laki-laki. Saya lahir pada tanggal 19 Agustus 2002 di Medan, Sumatera Utara. Saat ini, saya tinggal di Medan, Sumatera Utara. Pendidikan saya dimulai dari SDN 060884 untuk pendidikan dasar, kemudian melanjutkan ke SMPIT Al-Fityan Medan untuk pendidikan menengah pertama, dan SMAIT Al-Fitran Medan untuk pendidikan menengah atas. Sekarang, saya sedang menempuh pendidikan di Universitas Mikroskil. Hobbi dan minat saya adalah membaca novel serta bermain games.</p>
        </div>
    </div>
</div>

<div class="container">
        <h1 class="text-center mt-5 mb-4">Kontak Informasi</h1>
        <div class="row justify-content-center">
            <div class="col-md-6">
                <ul class="list-group">
                    <li class="list-group-item">Email: hadyanmerdeka@gmail.com</li>
                    <li class="list-group-item">Telepon/Wa: 081262169935</li>
                    <li class="list-group-item">Instagram: <a href="https://www.instagram.com/mhyazid/" target="_blank">@mhyazid</a></li>
                </ul>
            </div>
        </div>
    </div>
</body>
</html>
