<?php


//menu atas
$menu_atas = [
    'home' => 'Home',
    'product' => 'Product',
    'gallery' => 'Gallery',
    'about me' => 'About Me',
    'Feedback Form' => 'Feedback Form',


];

//menu bawah
$menu_bawah = [
    'home' => 'home.php',
    'product' => 'product.php',
    'gallery' => 'gallery.php',
    'about me' => 'aboutme.php',
    'Feedback Form' => 'form.php',

];
?>