<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
        <title>Form</title>
        <style>
            footer{
                position: absolute;
            }
        </style>
    </head>
    <body>
    <h1 class="text-center mt-4">Feedback Form</h1>
    <form method="POST">
    <div class='col-md-7 mx-auto mt-5'>
    <div class="form-group">
        <label for="nama_pelanggan">Nama Pelanggan</label> 
        <input id="nama_pelanggan" name="nama_pelanggan" type="text" class="form-control">
    </div>
    <div class="mb-3">
    <label for="exampleFormControlTextarea1" class="form-label">Feedback</label>
    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
    </div>
    <div class="form-group">
        <button name="submit" type="submit" class="btn btn-primary" onclick='thanksAlert()'>Submit</button>
    </div>
    </form>

    <script>
        function thanksAlert() {
            alert("Terimakasih atas feedback anda, semoga kedepannya layanan kami akan menjadi lebih baik lagi")
        }
    </script>
    </body>
</html>