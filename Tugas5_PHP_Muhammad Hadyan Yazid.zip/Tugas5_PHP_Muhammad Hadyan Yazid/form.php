<?php
require_once 'class.php';
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Nilai Ujian</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</head>
<body>
    <h1 class='text-center mb-5'>Form Nilai Ujian</h1>
    <form method="POST">
        <div class="col-9 mx-auto">
        <div class="row mb-3 mx-auto mt-5">
            <label for="nim" class="col-sm-3 col-form-label">NIM</label>
            <div class="col-sm-8">
            <input type="text" class="form-control" id="nim" name="nim">
            </div>
        </div>
        <div class="row mb-3 mx-auto mt-5">
            <label for="nama" class="col-sm-3 col-form-label">Nama</label>
            <div class="col-sm-8">
            <input type="text" class="form-control" id="nama" name="nama">
            </div>
        </div>
        <div class="row mb-3 mx-auto mt-5">
            <label for="Kuliah" class="col-sm-3 col-form-label">Kuliah</label>
            <div class="col-sm-8">
                <select class="form-select" aria-label="Default select example" name="kuliah">
                    <option selected>Pilih Universitas</option>
                    <option value="Universitas Mikroskil">Universitas Mikroskil</option>
                    <option value="Universitas Garus">Universitas Garut</option>
                    <option value="Universitas Sumatera Utara">Universitas Sumatera Utara</option>
                </select>
            </div>
        </div>
        <div class="row mb-3 mx-auto mt-5">
            <label for="matkul" class="col-sm-3 col-form-label">Mata Kuliah</label>
            <div class="col-sm-8">
            <select class="form-select" aria-label="Default select example" name="matkul">
                    <option selected>Pilih Matakuliah</option>
                    <option value="Pemrograman Berbasis Objek">Pemrograman Berbasis Objek</option>
                    <option value="Pelajaran Agama">Pelajaran Agama</option>
                    <option value="Fullstack Web">Fullstack Web</option>
            </select>
            </div>
        </div>
        <div class="row mb-3 mx-auto mt-5">
            <label for="nilai" class="col-sm-3 col-form-label">Nilai</label>
            <div class="col-sm-8">
            <input type="text" class="form-control" id="nilai" name="nilai">
        </div>
        <button type="submit" class="btn btn-primary mt-5 mx-auto col-2" name="submit">Simpan</button>
        </div>
    </form>


    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
</body>
</html>

<?php
error_reporting(0);

$nama=$_POST['nama'];
$nim=$_POST['nim'];
$kuliah=$_POST['kuliah'];
$matkul=$_POST['matkul'];
$nilai=$_POST['nilai'];


$mhs = new Mahasiswa("$nama","$nilai","$nim","$kuliah","$matkul");
$grade = $mhs->getGrade($nilai);
$predikat = $mhs->getPredikat($nilai);
$status = $mhs->getStatus($nilai);

$proses=$_POST['submit'];
if(isset($proses)){
    ?>
    <h2 class="text-center mt-5">Nilai Siswa</h2>
    <table class='table table-striped table-bordered table-hover table-dark'>
    <thead>
        <tr>
            <th>No</th>
            <th>NIM</th>
            <th>Nama</th>
            <th>Kuliah</th>
            <th>Mata Kuliah</th>
            <th>Nilai</th>
            <th>Grade</th>
            <th>Predikat</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
    <?php
        $no=1;
          echo '<tr>';
          echo '<td>'. $no .'</td>';
          echo '<td>'. $mhs->nim .'</td>';
          echo '<td>'. $mhs->nama .'</td>';
          echo '<td>'. $mhs->kuliah .'</td>';
          echo '<td>'. $mhs->matkul .'</td>';
          echo '<td>'. $mhs->nilai .'</td>';
          echo '<td>'. $grade .'</td>';
          echo '<td>'. $predikat .'</td>';
          echo '<td>'. $status .'</td>';
          echo '</tr>';
    ?>    
    </tbody>
</table>
<?php } ?>



