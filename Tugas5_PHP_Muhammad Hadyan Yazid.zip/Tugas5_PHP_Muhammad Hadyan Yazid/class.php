<?php
class Mahasiswa{
    public $nama;
    public $nilai;
    public $nim;
    public $kuliah;
    public $matkul;

    public function __construct($nama,$nilai,$nim,$kuliah,$matkul){
        $this->nama = $nama;
        $this->nim = $nim;
        $this->nilai = $nilai;
        $this->kuliah = $kuliah;
        $this->matkul = $matkul;
    }

    public function getGrade($nilai){
        $grade = '';
        if($nilai>=90 && $nilai<=100){
            $grade = 'A';
        }elseif($nilai>=76 && $nilai<=89){
            $grade = "B";
        }elseif($nilai>=60 && $nilai<=75){
            $grade = "C";
        }elseif($nilai>=40 && $nilai<=59){
            $grade = "D";
        }elseif($nilai>=0 && $nilai<=39){
            $grade = "E";
        }else{
            $grade = "Nilai invalid";
        }
        return $grade;
    }

    public function getPredikat($nilai){
        $grade = $this->getGrade($nilai); 
        $predikat = ''; 
    
        switch ($grade) {
            case 'A':  
                $predikat = "Memuaskan";
                break;
            
            case 'B':  
                $predikat = "Bagus";
                break;
            
            case 'C':  
                $predikat = "Cukup";
                break;
    
            case 'D':  
                $predikat = "Kurang";
                break;
    
            case 'E':  
                $predikat = "Buruk";
                break;
    
            default:
                $predikat = "-";
                break;
        }
        
        return $predikat;
    }

    public function getStatus($nilai){
        $ket = ($nilai>=65) ? "Lulus" : "Gagal";
        return $ket;
    }
}
?>